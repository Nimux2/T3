# Donors to the PostgreSQLClient project.

PostgreSQLClient is a project created by a student (Samuel MARZIN) who develops it in his spare time.
At first I created it for personal use but I quickly realized that it could be useful to the community.
I spent a lot of time going through the Postgres protocol documentation when I had no networking knowledge.
It takes a lot of effort so I thank all donors for considering my project at its fair value.


If you feel like it, you can buy me a cup of coffee.

<p align="center">
	<a href="https://paypal.me/MarzinSamuel"><img src="https://raw.githubusercontent.com/Marzin-bot/Ressources/main/paypal_btn_donateCC_LG_1.gif" alt="Donation PayPal"></a>
</p>


## DONORS
    
    Christian Kaltenecker
